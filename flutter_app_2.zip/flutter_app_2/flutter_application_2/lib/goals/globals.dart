import 'package:flutter_application_2/data/solicitar.dart';
import 'package:flutter_application_2/data/user.dart';
import 'package:flutter_application_2/data/veiculo.dart';

User? instance;
Veiculo? instanceVeiculo;
Solicitar? instanceSolicitar;
