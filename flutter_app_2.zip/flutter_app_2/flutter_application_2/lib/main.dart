import 'package:flutter/material.dart';
import 'package:flutter_application_2/login_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AlfaId',

      home: LoginPage(),
    );
  }
}
